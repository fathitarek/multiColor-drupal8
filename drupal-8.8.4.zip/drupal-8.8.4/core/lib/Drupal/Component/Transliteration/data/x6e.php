<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'ben', 'yuan', 'wen', 'ruo', 'fei', 'qing', 'yuan', 'ke', 'ji', 'she', 'yuan', 'se', 'lu', 'zi', 'du', 'qi',
  0x10 => 'jian', 'mian', 'pi', 'xi', 'yu', 'yuan', 'shen', 'shen', 'rou', 'huan', 'zhu', 'jian', 'nuan', 'yu', 'qiu', 'ting',
  0x20 => 'qu', 'du', 'fan', 'zha', 'bo', 'wo', 'wo', 'di', 'wei', 'wen', 'ru', 'xie', 'ce', 'wei', 'he', 'gang',
  0x30 => 'yan', 'hong', 'xuan', 'mi', 'ke', 'mao', 'ying', 'yan', 'you', 'hong', 'miao', 'sheng', 'mei', 'zai', 'hun', 'nai',
  0x40 => 'gui', 'chi', 'e', 'pai', 'mei', 'lian', 'qi', 'qi', 'mei', 'tian', 'cou', 'wei', 'can', 'tuan', 'mian', 'hui',
  0x50 => 'mo', 'xu', 'ji', 'pen', 'jian', 'jian', 'hu', 'feng', 'xiang', 'yi', 'yin', 'zhan', 'shi', 'jie', 'cheng', 'huang',
  0x60 => 'tan', 'yu', 'bi', 'min', 'shi', 'tu', 'sheng', 'yong', 'ju', 'dong', 'tuan', 'jiao', 'jiao', 'qiu', 'yan', 'tang',
  0x70 => 'long', 'huo', 'yuan', 'nan', 'ban', 'you', 'quan', 'zhuang', 'liang', 'chan', 'yan', 'chun', 'nie', 'zi', 'wan', 'shi',
  0x80 => 'man', 'ying', 'la', 'kui', 'feng', 'jian', 'xu', 'lou', 'wei', 'gai', 'xia', 'ying', 'po', 'jin', 'yan', 'tang',
  0x90 => 'yuan', 'suo', 'yuan', 'lian', 'yao', 'meng', 'zhun', 'cheng', 'ke', 'tai', 'ta', 'wa', 'liu', 'gou', 'sao', 'ming',
  0xA0 => 'zha', 'shi', 'yi', 'lun', 'ma', 'pu', 'wei', 'li', 'cai', 'wu', 'xi', 'wen', 'qiang', 'ze', 'shi', 'su',
  0xB0 => 'ai', 'qin', 'sou', 'yun', 'xiu', 'yin', 'rong', 'hun', 'su', 'suo', 'ni', 'ta', 'shi', 'ru', 'ai', 'pan',
  0xC0 => 'chu', 'chu', 'pang', 'weng', 'cang', 'mie', 'ge', 'dian', 'hao', 'huang', 'xi', 'zi', 'di', 'zhi', 'xing', 'fu',
  0xD0 => 'jie', 'hua', 'ge', 'zi', 'tao', 'teng', 'sui', 'bi', 'jiao', 'hui', 'gun', 'yin', 'gao', 'long', 'zhi', 'yan',
  0xE0 => 'she', 'man', 'ying', 'chun', 'lu', 'lan', 'luan', 'xiao', 'bin', 'tan', 'yu', 'xiu', 'hu', 'bi', 'biao', 'zhi',
  0xF0 => 'jiang', 'kou', 'shen', 'shang', 'di', 'mi', 'ao', 'lu', 'hu', 'hu', 'you', 'chan', 'fan', 'yong', 'gun', 'man',
];
